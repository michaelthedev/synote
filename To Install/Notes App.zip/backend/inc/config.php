<?php 
// +------------------------------------------------------------------------+
// | @author        : Michael Arawole (Logad Networks)
// | @author_url    : https://logad.net
// | @author_email  : logadscripts@gmail.com
// | @date          : 10 Jul, 2022 09:24AM
// +------------------------------------------------------------------------+
// | 2022 Logad Networks
// +------------------------------------------------------------------------+

// +----------------------------+
// | Configuration Class
// +----------------------------+

// Database Host
$dbHost = "localhost";
// Database Name
$dbName = "notes";
// Database Username
$dbUser = "root";
// Database Password
$dbPass = "";