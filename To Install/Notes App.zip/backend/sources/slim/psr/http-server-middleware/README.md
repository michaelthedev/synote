HTTP Server Middleware
======================

Provides the `MiddlewareInterface` of [PSR-15][psr-15].

[psr-15]: https://github.com/php-fig/fig-standards/blob/master/accepted/PSR-15-request-handlers.md
