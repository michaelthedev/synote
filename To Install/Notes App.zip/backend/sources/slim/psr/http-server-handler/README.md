HTTP Server Handler
===================

Provides the `RequestHandlerInterface` of [PSR-15][psr-15].

[psr-15]: https://github.com/php-fig/fig-standards/blob/master/accepted/PSR-15-request-handlers.md
